<?php
	$dbhost = "localhost";
	$dbuser = 'root';
	$dbpass = '';
	$connect = new mysqli($dbhost,$dbuser,$dbpass,"guvi");
?>